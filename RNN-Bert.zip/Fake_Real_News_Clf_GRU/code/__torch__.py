class RNN(Module):
  __parameters__ = []
  training : bool
  embedding : __torch__.torch.nn.modules.sparse.Embedding
  rnn : __torch__.torch.nn.modules.rnn.GRU
  fc : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.RNN,
    text: Tensor) -> Tensor:
    embedded = (self.embedding).forward(text, )
    _0 = (self.rnn).forward__0(embedded, None, )
    output, hidden, = _0
    _1 = torch.slice(torch.select(output, 0, -1), 0, 0, 9223372036854775807, 1)
    _2 = torch.slice(_1, 1, 0, 9223372036854775807, 1)
    _3 = (self.fc).forward(torch.squeeze(_2, 0), )
    return torch.squeeze(_3, 1)
