def embedding(input: Tensor,
    weight: Tensor,
    padding_idx: Optional[int]=None,
    max_norm: Optional[float]=None,
    norm_type: float=2.,
    scale_grad_by_freq: bool=False,
    sparse: bool=False) -> Tensor:
  if torch.__isnot__(padding_idx, None):
    padding_idx1 = unchecked_cast(int, padding_idx)
    if torch.gt(padding_idx1, 0):
      _0 = torch.lt(padding_idx1, torch.size(weight, 0))
      if _0:
        pass
      else:
        ops.prim.RaiseException("Exception")
      padding_idx2 = padding_idx1
    else:
      if torch.lt(padding_idx1, 0):
        _1 = torch.neg(torch.size(weight, 0))
        if torch.ge(padding_idx1, _1):
          pass
        else:
          ops.prim.RaiseException("Exception")
        padding_idx3 = torch.add(torch.size(weight, 0), padding_idx1)
      else:
        padding_idx3 = padding_idx1
      padding_idx2 = padding_idx3
    padding_idx0 = padding_idx2
  else:
    padding_idx0 = -1
  if torch.__isnot__(max_norm, None):
    input0 = torch.contiguous(input, memory_format=0)
  else:
    input0 = input
  _2 = torch.embedding(weight, input0, padding_idx0, scale_grad_by_freq, sparse)
  return _2
def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _3 = torch.__isnot__(bias, None)
  else:
    _3 = False
  if _3:
    bias0 = unchecked_cast(Tensor, bias)
    ret = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output0 = torch.add_(output, bias1, alpha=1)
    else:
      output0 = output
    ret = output0
  return ret
