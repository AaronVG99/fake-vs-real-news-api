class GRU(Module):
  __parameters__ = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0", "weight_ih_l1", "weight_hh_l1", "bias_ih_l1", "bias_hh_l1", ]
  weight_ih_l0 : Tensor
  weight_hh_l0 : Tensor
  bias_ih_l0 : Tensor
  bias_hh_l0 : Tensor
  weight_ih_l1 : Tensor
  weight_hh_l1 : Tensor
  bias_ih_l1 : Tensor
  bias_hh_l1 : Tensor
  training : bool
  _flat_weights_names : List[str]
  _all_weights : List[List[str]]
  _flat_weights : List[Tensor]
  bidirectional : Final[bool] = False
  input_size : Final[int] = 128
  hidden_size : Final[int] = 128
  num_layers : Final[int] = 2
  mode : Final[str] = "GRU"
  bias : Final[bool] = True
  dropout : Final[float] = 0.20000000000000001
  batch_first : Final[bool] = False
  def forward__0(self: __torch__.torch.nn.modules.rnn.GRU,
    input: Tensor,
    hx: Optional[Tensor]=None) -> Tuple[Tensor, Tensor]:
    _0 = torch.size(input, 1)
    if torch.__is__(hx, None):
      _1 = ops.prim.dtype(input)
      _2 = ops.prim.device(input)
      hx0 = torch.zeros([2, _0, 128], dtype=_1, layout=None, device=_2, pin_memory=None)
    else:
      hx1 = unchecked_cast(Tensor, hx)
      hx0 = (self).permute_hidden(hx1, None, )
    _3 = (self).check_forward_args(input, hx0, None, )
    _4, _5 = torch.gru(input, hx0, self._flat_weights, True, 2, 0.20000000000000001, self.training, False, False)
    _6 = (_4, (self).permute_hidden(_5, None, ))
    return _6
  def forward__1(self: __torch__.torch.nn.modules.rnn.GRU,
    input: __torch__.torch.nn.utils.rnn.PackedSequence,
    hx: Optional[Tensor]=None) -> Tuple[__torch__.torch.nn.utils.rnn.PackedSequence, Tensor]:
    input0, batch_sizes, sorted_indices, unsorted_indices, = input
    max_batch_size = torch.select(batch_sizes, 0, 0)
    max_batch_size0 = int(max_batch_size)
    if torch.__is__(hx, None):
      _7 = ops.prim.dtype(input0)
      _8 = ops.prim.device(input0)
      hx2 = torch.zeros([2, max_batch_size0, 128], dtype=_7, layout=None, device=_8, pin_memory=None)
    else:
      hx3 = unchecked_cast(Tensor, hx)
      hx2 = (self).permute_hidden(hx3, sorted_indices, )
    _9 = (self).check_forward_args(input0, hx2, batch_sizes, )
    _10, _11 = torch.gru(input0, batch_sizes, hx2, self._flat_weights, True, 2, 0.20000000000000001, self.training, False)
    output_packed = __torch__.torch.nn.utils.rnn.PackedSequence(_10, batch_sizes, sorted_indices, unsorted_indices)
    _12 = (self).permute_hidden(_11, unsorted_indices, )
    return (output_packed, _12)
  def permute_hidden(self: __torch__.torch.nn.modules.rnn.GRU,
    hx: Tensor,
    permutation: Optional[Tensor]) -> Tensor:
    _13 = __torch__.torch.nn.modules.rnn.apply_permutation
    _14 = uninitialized(Tensor)
    if torch.__is__(permutation, None):
      _15, _16, permutation0 = True, hx, _14
    else:
      _15, _16, permutation0 = False, _14, unchecked_cast(Tensor, permutation)
    if _15:
      _17 = _16
    else:
      _17 = _13(hx, permutation0, 1, )
    return _17
  def check_forward_args(self: __torch__.torch.nn.modules.rnn.GRU,
    input: Tensor,
    hidden: Tensor,
    batch_sizes: Optional[Tensor]) -> None:
    _18 = (self).check_input(input, batch_sizes, )
    expected_hidden_size = (self).get_expected_hidden_size(input, batch_sizes, )
    _19 = (self).check_hidden_size(hidden, expected_hidden_size, "Expected hidden size {}, got {}", )
    return None
  def check_input(self: __torch__.torch.nn.modules.rnn.GRU,
    input: Tensor,
    batch_sizes: Optional[Tensor]) -> None:
    if torch.__isnot__(batch_sizes, None):
      expected_input_dim = 2
    else:
      expected_input_dim = 3
    _20 = torch.ne(torch.dim(input), expected_input_dim)
    if _20:
      ops.prim.RaiseException("Exception")
    else:
      pass
    _21 = torch.ne(128, torch.size(input, -1))
    if _21:
      ops.prim.RaiseException("Exception")
    else:
      pass
    return None
  def get_expected_hidden_size(self: __torch__.torch.nn.modules.rnn.GRU,
    input: Tensor,
    batch_sizes: Optional[Tensor]) -> Tuple[int, int, int]:
    if torch.__isnot__(batch_sizes, None):
      batch_sizes0 = unchecked_cast(Tensor, batch_sizes)
      mini_batch0 = torch.select(batch_sizes0, 0, 0)
      mini_batch = int(mini_batch0)
    else:
      mini_batch = torch.size(input, 1)
    return (2, mini_batch, 128)
  def check_hidden_size(self: __torch__.torch.nn.modules.rnn.GRU,
    hx: Tensor,
    expected_hidden_size: Tuple[int, int, int],
    msg: str="Expected hidden size {}, got {}") -> None:
    _22 = torch.size(hx)
    _23, _24, _25, = expected_hidden_size
    if torch.ne(_22, [_23, _24, _25]):
      ops.prim.RaiseException("Exception")
    else:
      pass
    return None
def apply_permutation(tensor: Tensor,
    permutation: Tensor,
    dim: int=1) -> Tensor:
  _26 = torch.index_select(tensor, dim, permutation)
  return _26
