class Embedding(Module):
  __parameters__ = ["weight", ]
  weight : Tensor
  training : bool
  sparse : Final[bool] = False
  embedding_dim : Final[int] = 128
  scale_grad_by_freq : Final[bool] = False
  num_embeddings : Final[int] = 10002
  padding_idx : Final[None] = None
  max_norm : Final[None] = None
  norm_type : Final[float] = 2.
  def forward(self: __torch__.torch.nn.modules.sparse.Embedding,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.embedding
    _1 = _0(input, self.weight, None, None, 2., False, False, )
    return _1
